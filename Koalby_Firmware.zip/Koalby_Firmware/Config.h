#ifndef config_h
#define config_h
//File For Reference Only Possible use Later maybe

/*
 * Motor 1 - Herkulex, Right Forearm
 * Motor 2 - Herkulex, Right Upper Arm
 * Motor 3 - Herkulex, Right Arm Connector
 * Motor F - Herkulex, Right Shoulder
 * 
 * Motor B - Herkulex, Left Forearm
 * Motor A - Herkulex, Right Upper Arm
 * Motor 6 - Herkulex, Right Arm Connector
 * Motor 7 - Herkulex, Right Shoulder
 * 
 * Motor 11 - Herkulex, Torso Double Rotation Backside
 * Motor 12 - Herkulex, Torso Double Rotation Frontside
 * Motor 13 - Herkluex, Abdomen 
 */
#endif
